﻿namespace Payment.Configurations
{
    public class JwtConfig
    {
        public string Secret { get; set; }
    }
}
